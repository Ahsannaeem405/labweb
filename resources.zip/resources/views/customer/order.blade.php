@extends('admin.layouts.default')
@section('content')

    @include('admin.layouts.sidebar')

    @include('admin.layouts.header')
    <link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css">
    <style>
        .border_div {
            border: 1px solid gray;
            border-radius: 5px;
        }

        @media only screen and (max-width: 375px) {
            .a_tag {
                font-size: 13px;
            }
        }

    </style>

    @php $role=\Illuminate\Support\Facades\Auth::user()->role; @endphp

    <!-- ########## START: MAIN PANEL ########## -->
    <div class="br-mainpanel">
        <div class="pd-30">
            @include('partials.component')

            <div class="row">
                <div class="col-12 pt-2">
                    <a href="{{ url("$role/customers") }}"><i class="fas fa-chevron-left"></i> Back to Customer List</a>
                </div>
                <div class="col-lg-3 col-md-6 pt-2 text-dark">

                    <div class="row">


                        <div class="col-xl-3  col-lg-5 col-3">
                            <i class="fas fa-user-circle" style="font-size: 68px;"></i>

                        </div>
                        <div class="col-xl-9 col-lg-7  col-6">

                            <h6 style="text-transform: uppercase;">{{ $cus->name }}  {{isset($cus->show->surname) ?$cus->show->secondname." ".$cus->show->surname :null}}</h6>
                            <span>#{{ $cus->id+18910 }}</span>
                            <p><span class="text-bold">{{ $cus->gender }}</span> Born on <span
                                    class="text-bold">{{\Carbon\Carbon::parse($cus->dob)->format('m-d-Y')  }}</span></p>

                        </div>


                    </div>
                </div>
                <div class="col-lg-9 col-md-6 pt-2 text-dark" style="   text-align:end; margin-top: 38px;">
                    <a href="{{ url("$role/edit/customer/$cus->id") }}">
                        <button class="btn btn-secondary">Edit
                            Customer
                        </button>
                    </a>
                    <a href="{{ url("$role/place/order/new/$cus->id") }}">
                        <button class="btn btn-primary">Place
                            Order
                        </button>
                    </a>
                </div>
                <div class="col-lg-12 col-12 pt-3 text-dark">
                    <div class="row" style="padding-left: 15px;">

                        <div class="col-lg-3 col-md-4 col-12">
                            <p><i class="far fa-envelope"></i> {{ $cus->email }}</p>
                        </div>
                        <div class="col-lg-2 col-md-4 col-12">
                            <p><i class="fas fa-mobile-alt "></i> {{ $cus->phone }}</p>
                        </div>
                        <div class="col-lg-2 col-md-4 col-12">
                            <p>
                                <i class="fas fa-map-marker-alt "></i>  {{ isset($cus->show->surname) ? $cus->show->address.' '. $cus->show->address2.' '.$cus->show->town .' '.$cus->show->Province .' '.$cus->show->zip.' '.$cus->show->Country  : $cus->address.' '. $cus->address2.' '. $cus->town.' '. $cus->state.' '.  $cus->zip.' '.$cus->country}}
                            </p>
                        </div>
                    </div>


                </div>
                <div class="col-lg-4 col-12 pt-2 text-dark text-right">


                </div>
            </div>
        </div><!-- d-flex -->

        <div class="br-pagebody mg-t-5 pd-x-30">

            <div class="row">
                <div class="col-lg-8 col-12">


                    <div class="card bd-0 shadow-base p-3">
                        <div class="row">
                            <div class="col-12">
                                <h5 style="color:black">Order</h5>
                            </div>
                            <table class="table table-striped">
                                <thead>
                                <tr>

                                </tr>
                                </thead>
                                <tbody>

                                @foreach ($order as $orders)
                                    {{-- @dd($orders->test_type ) --}}

                                    @if ($orders->main_status == 'user' and $orders->duplicate != 2)
                                        @if (isset($orders->show->Select_the_test))


                                            <tr>
                                                <td style="color: black">
                                                    <a href="{{ url("/$role/customer/view/order/$orders->id/$cus->id" ) }}">
                                                        <button><i class="fa fa-info-circle p-1"></i>Detail</button>
                                                        </i>
                                                    </a>
                                                </td>


                                                <td style="color: black" attrr="{{ $orders->id }}" rolee="{{ $role }}">
                                                    #
                                                </td>


                                                <td style="color: black" attrr="{{ $orders->id }}" rolee="{{ $role }}">

                                                    {{ $orders->show->Select_the_test }}


                                                </td>
                                                <td style="color: black" attrr="{{ $orders->id }}" rolee="{{ $role }}">
                                                    @if (isset($orders->show->created_at))
                                                        {{ \Carbon\Carbon::parse($orders->show->created_at)->format('m-d-Y')}}
                                                    @endif


                                                </td>

                                                <td>
                                                    <a onclick="return confirm('Are you sure you want to approve this item?');"
                                                       href="{{ url("$role/order/approve/$orders->id/$cus->id") }}"
                                                       class="btn btn-secondary Draft">{{ 'Draft' }}</a>
                                                </td>

                                                <td attrr="{{ $orders->id }}" rolee="{{ $role }}">
                                                    @if ($orders->display_status == null)
                                                        <a disabled
                                                           onclick="return confirm('Are you sure you want to delete this item?');"
                                                           href="{{ url("$role/order/cancel/$orders->id") }}"
                                                           class="a_tag"
                                                           style="color: blue;text-decoration: underline">Cancel</a>
                                                    @endif
                                                </td>
                                                <td>
                                                    <a href="{{ url("/$role/customer/view/order/$orders->id/$cus->id" ) }}">
                                                        <i class="fa fa-arrow-right" aria-hidden="true">
                                                        </i>
                                                    </a>
                                                </td>
                                            </tr>
                                        @endif

                                    @elseif($orders->duplicate != 2)
                                        <tr>

                                            <td>
                                                <a href="{{ url("/$role/customer/view/order/$orders->id/$cus->id" ) }}">
                                                    <button><i class="fa fa-info-circle p-1"></i>Detail</button>
                                                    </i>
                                                </a>
                                            </td>

                                            <td style="color: black" class="cust" attrr="{{ $orders->id }}"
                                                rolee="{{ $role }}">#{{ $orders->id+3000 }} </td>


                                            <td style="color: black" class="cust" attrr="{{ $orders->id }}"
                                                rolee="{{ $role }}">
                                                {{ $orders->test_type }}
                                            </td>
                                            <td style="color: black" class="cust" attrr="{{ $orders->id }}"
                                                rolee="{{ $role }}">
                                                {{ \Carbon\Carbon::parse($orders->order_date)->format('m-d-Y h:i A')}}   </td>

                                            <td style="color: black" class="cust" attrr="{{ $orders->id }}"
                                                rolee="{{ $role }}">
                                                @if ($orders->display_status == null)
                                                    <button class="btn btn-warning">{{ 'pending' }}</button>

                                                @else

                                                    <button
                                                        class="btn     @if ($orders->display_status == 'negative') btn-success @else btn-danger  @endif">{{ $orders->display_status }}</button>

                                                @endif
                                            </td>


                                            <td class="cust" attrr="{{ $orders->id }}"
                                                rolee="{{ $role }}">
                                                @if ($orders->display_status == null) <a
                                                    disabled
                                                    onclick="return confirm('Are you sure you want to delete this item?');"
                                                    href="{{ url("$role/order/cancel/$orders->id") }}"
                                                    class="a_tag"
                                                    style="color: blue;text-decoration: underline">Cancel</a>
                                                @endif
                                            </td>
                                            <td>
                                                <a href="{{ url("/$role/customer/view/order/$orders->id/$cus->id", ) }}">
                                                    <i class="fa fa-arrow-right" aria-hidden="true">
                                                    </i>
                                                </a>
                                            </td>
                                        </tr>

                                    @endif
                                @endforeach

                                </tbody>
                            </table>
                        </div>


                    </div>


                    <br>

                    <div class="card bd-0 shadow-base p-3">
                        <div class="row">
                            <div class="col-12">
                                <h5 style="color:black">Invoices</h5>
                            </div>
                            <table class="table table-striped">
                                <thead>
                                <tr>

                                </tr>
                                </thead>
                                <tbody>

                                @foreach ($order as $orders)
                                    @if ($orders->step > 1 && $orders->display_status != 'Canceled')
                                        <tr>

                                            <td style="color:black" class="invoi" attrr="{{ $orders->id }}"
                                                rolee="{{ $role }}">#{{ $orders->id+3000 }}
                                                <span> - </span>
                                                <span><i class="fas fa-calendar-minus"></i>
                                            </td>
                                            <td style="color:black" class="invoi" attrr="{{ $orders->id }}"
                                                rolee="{{ $role }}">

                                                {{ \Carbon\Carbon::parse( $orders->payment_date)->format('m-d-Y h:i A')}}



                                            </td>

                                            <td style="color:black"
                                                rolee="{{ $role }}">
                                                @if ($orders->step > 2)
                                                    <button class="btn btn-success">Paid</button>

                                                @else
                                                    <button data-toggle="modal"
                                                            data-target="#exampleModal{{$orders->id}}"
                                                            class="btn btn-primary">
                                                        Pay Now
                                                    </button>

                                                @endif
                                            </td>
                                            <td style="color:black" class="invoi" attrr="{{ $orders->id }}"
                                                rolee="{{ $role }}">
                                                <p style="    font-size: 18px;"> ${{ $orders->payment_amount }}</p>
                                            </td>
                                            <td>
                                                <a href="{{ url("/$role/customer/view/invoice/$orders->id/$cus->id") }}">
                                                    <i class="fa fa-arrow-right" aria-hidden="true">
                                                    </i>
                                                </a>

                                            </td>
                                        </tr>


                                        <div class="modal fade" id="exampleModal{{$orders->id}}" tabindex="-1"
                                             role="dialog"
                                             aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content" style="width: 30rem">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel"> Pay now</h5>
                                                        <button type="button" class="close" data-dismiss="modal"
                                                                aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form method="post"
                                                              action="{{url("$role/pay/invoice/$orders->id")}}">
                                                            @csrf
                                                            <label>Please select Payment Method</label>
                                                            <select class="form-control" name="payment_method" required>
                                                                <option selected value="">Please select</option>
                                                                <option value="card">card</option>
                                                                <option value="cash">cash</option>
                                                                <option value="others">others</option>
                                                            </select>
                                                            <lable>Please enter Amount</lable>
                                                            <input type="number" name="payment_amount" value="{{$orders->priceList->price}}"
                                                                   required min="1" class="form-control"
                                                                   placeholder="Please enter amount">

                                                            <lable>Payment detail</lable>

                                                            <textarea class="form-control" name="payment_detail" id=""
                                                                      cols="10" rows="5"
                                                                      placeholder="payment detail"></textarea>

                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                                data-dismiss="modal">Close
                                                        </button>
                                                        <button type="submit" class="btn btn-primary">Submit</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>


                                    @endif
                                @endforeach

                                </tbody>
                            </table>
                        </div>


                    </div>


                </div>
                <div class="col-lg-4 col-12">


                    <div class="card bd-0 shadow-base p-3">
                        <div class="row" style="height: 300px;overflow: auto">
                            <div class="col-12">
                                <p style="    font-size: 20px;color: black;">Documents</p>

                            </div>
                            @foreach ($document as $documents)
                                <div class="w-100 p-1 m-1" style="background-color: white"> <span class="mt-1"
                                                                                                  style="color: black;padding: 7px;"> @if (isset($documents->path))
                                            <i class="fa fa-file-text-o" style="    font-size: 15px;color: black;"></i>

                                        @if($documents->type!=1)    {{ 'Smartwaiver Consent.pdf' }} @else   {{ $documents->path }}  @endif @endif </span>


                                    <a href="{{ asset("uploads/stock/$documents->path") }}" target="_blank"> <span
                                            class="p-1" style="color: black;float: right"><i
                                                class="fa fa-search"></i></span>
                                    </a>
                                    <a href="{{ url("$role/delete/document/$documents->id") }}"
                                       onclick="return confirm('Are you sure you want to delete this item?');"><span
                                            class="p-1" style="color: black;float: right;color: red"><i
                                                class="fa fa-trash"></i></span></a>
                                    <a href="{{ asset("uploads/stock/$documents->path") }}" download> <span
                                            class="p-1" style="color: black;float: right">download</span> </a>


                                </div>

                            @endforeach

                            <form class="w-100" action="{{ url("$role/upload/document/$cus->id") }}"
                                  method="post" enctype="multipart/form-data">
                                @csrf
                                <lable class="ml-2 mt-5 font-weight-bold">Upload Document</lable>
                                <div class="col-12">
                                    <div class="row">
                                        <div class="col-8 pt-2" style="padding: 0px">
                                            <input type="file" name="file" required class="form-control">

                                        </div>
                                        <div class="col-2 pt-2 text-right">
                                            <button type="submit" class="btn btn-success">Submit</button>

                                        </div>
                                    </div>

                                </div>

                            </form>
                        </div>

                    </div>
                    <div class="card bd-0 shadow-base p-3 mt-2" style="    height: 300px;overflow: auto">
                        <div class="row">
                            <div class="col-12">
                                <p style="font-size: 18px;
                                color: black;">Events Timeline</p>
                            </div>


                            <div class="col-7 pt-2">
                                <i class="far fa-user-circle" style="    font-size: 22px;"></i> &nbsp; <span>New Patient Created</span>
                            </div>
                            <div class="col-5 pt-2">
                                <p>{{ $cus->created_at }}</p>
                            </div>

                            @foreach ($order as $orders)
                                @if ($orders->order_id != null)
                                    <div class="col-7 pt-2">
                                        <i class="far fa-user-circle" style="    font-size: 22px;"></i>&nbsp; Order
                                        #{{ $orders->id+3000 }} - created
                                    </div>
                                    <div class="col-5 pt-2">
                                        <p>

                                            {{ \Carbon\Carbon::parse($orders->created_at)->format('m-d-Y h:i A')}}

                                            </p>
                                    </div>


                                    @if ($orders->payment_date != null)
                                        <div class="col-7 pt-2">
                                            <i class="far fa-user-circle" style="    font-size: 22px;"></i> &nbsp; Order
                                            #{{ $orders->id+3000 }} - Invoice paid
                                        </div>
                                        <div class="col-5 pt-2">
                                            <p>


                                                {{ \Carbon\Carbon::parse($orders->payment_date)->format('m-d-Y h:i A')}}

                                            </p>
                                        </div>
                                    @endif

                                    @if ($orders->date != null)
                                        <div class="col-7 pt-2">
                                            <i class="far fa-user-circle" style="    font-size: 22px;"></i>&nbsp; Order
                                            #{{ $orders->id+3000 }} - Released
                                        </div>
                                        <div class="col-5 pt-2">
                                            <p>
                                                {{ \Carbon\Carbon::parse($orders->date)->format('m-d-Y h:i A')}}

                                            </p>
                                        </div>
                                    @endif
                                @endif

                            @endforeach


                        </div>

                    </div>



                    <div class="card bd-0 shadow-base p-3 mt-2" style="    height: 300px;overflow: auto">
                        <div class="row">
                            <div class="col-12">
                                <p style="font-size: 18px;
                                color: black;">Insurance Information</p>
                            </div>


                            <div class="col-12">
                               <h5 class="text-center">Primary Insurance</h5>  &nbsp;
                            </div>
                            <div class="col-12">
                                <lable>Primary Insurance:</lable>
                                <span class="ml-2">{{ isset($cus->show->primary_ins)  ? $cus->show->primary_ins :  $cus->primary_ins }}</span>
                            </div>

                            <div class="col-12">
                                <lable>Policy Holder Name:</lable>
                                <span class="ml-2">{{ isset($cus->show->policy_holder_name1)  ? $cus->show->policy_holder_name1 :  $cus->policy_holder_name1 }}</span>
                            </div>

                            <div class="col-12">
                                <lable>Relationship Patient:</lable>
                                <span class="ml-2">{{ isset($cus->show->relationship_patient1)  ? $cus->show->relationship_patient1 :  $cus->relationship_patient1 }}</span>
                            </div>

                            <div class="col-12">
                                <lable>Policy Holder DOB:</lable>
                                <span class="ml-2">{{ isset($cus->show->policy_holder_dob1)  ? $cus->show->policy_holder_dob1 :  $cus->policy_holder_dob1 }}</span>
                            </div>


                            <div class="col-12">
                                <lable>Policy # / Member ID:</lable>
                                <span class="ml-2"> {{ isset($cus->show->policy_member_id1)  ? $cus->show->policy_member_id1 :  $cus->policy_member_id1 }}</span>
                            </div>

                            <div class="col-12">
                                <lable>Group #:</lable>
                                <span class="ml-2">{{ isset($cus->show->group1)  ? $cus->show->group1 :  $cus->group1 }}</span>
                            </div>


                            <div class="col-12">
                                <h5 class="text-center">Secondary Insurance</h5>  &nbsp;
                            </div>
                            <div class="col-12">
                                <lable>Primary Insurance:</lable>
                                <span class="ml-2">{{ isset($cus->show->secondary_ins)  ? $cus->show->secondary_ins :  $cus->secondary_ins }}</span>
                            </div>

                            <div class="col-12">
                                <lable>Policy Holder Name:</lable>
                                <span class="ml-2">{{ isset($cus->show->policy_holder_name2)  ? $cus->show->policy_holder_name2 :  $cus->policy_holder_name2 }}</span>
                            </div>

                            <div class="col-12">
                                <lable>Relationship Patient:</lable>
                                <span class="ml-2">{{ isset($cus->show->relationship_patient2)  ? $cus->show->relationship_patient2 :  $cus->relationship_patient2 }}</span>
                            </div>

                            <div class="col-12">
                                <lable>Policy Holder DOB:</lable>
                                <span class="ml-2">{{ isset($cus->show->policy_holder_dob2)  ? $cus->show->policy_holder_dob2 :  $cus->policy_holder_dob2 }}</span>
                            </div>


                            <div class="col-12">
                                <lable>Policy # / Member ID:</lable>
                                <span class="ml-2"> {{ isset($cus->show->policy_member_id2)  ? $cus->show->policy_member_id2 :  $cus->policy_member_id2 }}</span>
                            </div>

                            <div class="col-12">
                                <lable>Group #:</lable>
                                <span class="ml-2">{{ isset($cus->show->group2)  ? $cus->show->group2 :  $cus->group2 }}</span>
                            </div>






                        </div>

                    </div>


                </div>


            </div>


        </div><!-- br-pagebody -->
        @include('admin.layouts.footer')
    </div><!-- br-mainpanel -->
    <!-- ########## END: MAIN PANEL ########## -->

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>


    <script>
        $(document).ready(function () {
            $('.cust').click(function () {

                var id = $(this).attr('attrr');
                var cus = {{$cus->id}};
                var rolee = $(this).attr('rolee');
                var url = '/' + rolee + '/customer/view/order/' + id + '/' + cus;
                $(location).attr('href', url);

            });
        });
    </script>

    <script>
        $(document).ready(function () {
            $('.invoi').click(function () {

                var id = $(this).attr('attrr');
                var cus = {{$cus->id}};

                var rolee = $(this).attr('rolee');
                var url = '/' + rolee + '/customer/view/invoice/' + id + '/' + cus;
                $(location).attr('href', url);

            });
        });
    </script>




@endsection
