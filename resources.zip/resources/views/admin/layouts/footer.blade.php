<footer class="br-footer">
    <div class="footer-left">
      <div class="mg-b-2">Copyright &copy; 2022. M3A Tech. All Rights Reserved.</div>

    </div>
  </footer>
